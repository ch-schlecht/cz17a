import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.UnknownHostException;

public class Client {

	public static void main(String[] args) throws UnknownHostException, IOException {
		String hostName = "127.0.0.1";
		int portNumber = 8080;
		
		Socket clientSocket = new Socket(hostName, portNumber);
		
		BufferedReader FromServer = new BufferedReader(new InputStreamReader(clientSocket.getInputStream()));
		DataOutputStream outToServer = new DataOutputStream(clientSocket.getOutputStream());
		BufferedReader inFromUser = new BufferedReader(new InputStreamReader(System.in));

		while (true) {  
		    // Check if there's anything to receive
		    while (FromServer.ready()) {
		        // receive from server
		        System.out.println("Message from Server: " + FromServer.readLine());
		    }
		    if (inFromUser.ready()) {
		        int ch = inFromUser.read();

		        // write to server
		        outToServer.writeChar(ch);
		    }
		}
	}
}
