Die Testklasse befindet sich direkt im Projekt in einem separaten Package und kann dort direkt aus der IDE (z.b. Eclipse in unserem Fall)
ausgef�hrt werden.