package application;

import java.io.File;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
/**
 * Controller for the main_app.fxml and Main.java
 * @author Michael
 * @version 1.0
 */
public class Controller {

	@FXML private Button close;
	@FXML private TextField path;
	
	/**
	 * For Close Button
	 * @param event
	 * @since 1.0
	 */
	@FXML protected void close(ActionEvent event){
		System.exit(0);
	}

	/**
	 * Starts the import 
	 * @param event
	 * @since 1.0
	 */
	@FXML protected void impor(ActionEvent event){
		
		String pathS = path.getText(); //get Path from TextInput
		
		if(pathS.endsWith(".csv")){ //check if it is an csv file
	
			if((new File(pathS)).exists()){ //check if file exist
				CSVIO io = new CSVIO(pathS); //create an CSVIO
				ServerManager manager = new ServerManager(); //create ServerManager
				
				for(String[] data :io.read()){ //for every row
					manager.insert(data); //insert data in database
				}
			
				manager.disconnect(); //disconnect from server
				
			}else{
				System.err.println("This File dosnt exist");
			}
		
			
			
		}
		else{
			System.err.println("This Import-Tool only works with csv Files");
		}
		
	
	
	}

}
