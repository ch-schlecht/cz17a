package cz17a.gamification.restserver;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

/**
 * Class to Handle all /question requests
 * @author Michael
 * @version 1.0
 */
@Path("/questions")
public class QuestionResource {

	QuestionService questionService = new QuestionService();
	
	/**
	 * GET requests
	 * @return list of all Questions
	 */
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public List<Question> getQuestions() {
		return questionService.getAllQuestions();
	}
	
	/**
	 * POST Request
	 * @param question Question to Add
	 * @return added Question
	 */
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Question addQuestion(Question question) {
		return questionService.addQuestion(question);
	}
	
	/**
	 * GET request to all /question/{ID}
	 * @param id of requested question
	 * @return question 
	 */
	@GET
	@Path("/{ID}")
	@Produces(MediaType.APPLICATION_JSON)
	public Question getQuestion(@PathParam("ID") int id) {
		return questionService.getQuestion(id);
	}
	
	
	
	
}
