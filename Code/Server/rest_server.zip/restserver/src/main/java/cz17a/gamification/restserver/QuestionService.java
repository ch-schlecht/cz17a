package cz17a.gamification.restserver;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import cz17a.gamification.restserver.sql.ServerManager;
/**
 * Service with all Methods for the QuestionResource
 * @author Michael
 * @version 1.0
 */
public class QuestionService {

	/**
	 * Return all Questions 
	 * @return list of all questions
	 * @since 1.0
	 */
	public List<Question> getAllQuestions(){
		List<Question> list = new ArrayList<>();
		
		Statement stmt;
		ResultSet set;
	
		try {
			stmt = ServerManager.query("SELECT * From question");
			set = stmt.getResultSet();
			while(set.next()) {
				list.add(new Question(set.getInt(1),set.getFloat(2),set.getString(3),set.getInt(4),set.getInt(5),set.getString(6),set.getInt(7)));
			}
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return list;
	}
	
	/**
	 * Get one specified Question
	 * @param id of requested Question
	 * @return Question with id
	 * @since 1.0
	 */
	public Question getQuestion(int id) {
	
		Question res = null;
		Statement stmt;
		ResultSet set;
	
		try {
			stmt = ServerManager.query("SELECT * From question WHERE ID = "+id);
			set = stmt.getResultSet();
			while(set.next()) {
				res = new Question(set.getInt(1),set.getFloat(2),set.getString(3),set.getInt(4),set.getInt(5),set.getString(6),set.getInt(7));
			}
			stmt.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		return res;
	}
	
	/**
	 * Add Question to Database
	 * @param question Question to Add
	 * @return added question
	 * @since 1.0
	 */
	public Question addQuestion(Question question) {
		//generate ID
		int ID = ServerManager.countTable("question")+1;
		ServerManager.update("INSERT INTO question(id,response_time,questioning,dynamic_difficulty,static_difficulty,topic,quiz_id) VALUES ("+ID+","+question.response_time+","+question.questioning+","+question.dynamic_difficulty+","+question.static_difficulty+","+question.topic+","+question.quiz_id+")");
		return question;
	}
	
	/**
	 * Update Qestion
	 * @param question to update
	 * @return updatet question
	 * @since 1.0
	 */
	public Question updateQuestion(Question question) {
		
		return null;
	}
	
	/**
	 * remove Question
	 * @param id of question to be removed
	 * @return removed question
	 * @since 1.0
	 */
	public Question removeQuestion(int id) {
		return null;
	}
	
}
