package application;

import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.Base64;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

public class PasswordManager {

	
	
	public static byte[] generateSalt() {
		SecureRandom random = new SecureRandom();
		return random.generateSeed(20);
	}
	
	public static String hash(String pw, byte[] salt) {
		KeySpec spec  = new PBEKeySpec(pw.toCharArray(), salt, 65536, 128);
		try {
			SecretKeyFactory f = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
			Base64.Encoder enc = Base64.getEncoder();
			byte [] hash = f.generateSecret(spec).getEncoded(); 
			return enc.encodeToString(hash);
		} catch (NoSuchAlgorithmException | InvalidKeySpecException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return null;
	}
	
}
