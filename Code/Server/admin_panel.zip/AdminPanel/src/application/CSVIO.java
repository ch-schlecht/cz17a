package application;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

/**
 * Class to read Questions/Answers in CSV Files
 * @author Michael
 * @version 1.0
 */
public class CSVIO {

	private BufferedReader br;
	
	/**
	 * Contructor
	 * seeting up BufferedReader
	 * @param file File to read
	 * @since 1.0
	 */
	public CSVIO(BufferedReader br){
		this.br = br;
	}
	
	
	
	/**
	 * Convert String of CSV into Data-Construct
	 * @return Data with rows in ArrayList and coulumns in String-Array
	 * @since 1.0
	 */
	public ArrayList<String[]> read(){
		ArrayList<String[]> list = new ArrayList<>(); //list for all rows
		String line = ""; //line for reader
		try {
			while(null!=(line=br.readLine())){ //while not eof
				//line = line.replace(" ", "_"); ?TODO kann weg?
				list.add(line.split(";")); //ever coulumn ends with an ;
			}
			
		} catch (IOException e) {
			System.out.println("Unable to read File");
			
		}
		return list;
	}
	
	
}
