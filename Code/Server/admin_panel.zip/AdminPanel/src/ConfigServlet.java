import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import application.ServerManager;

/**
 * Servlet implementation class ConfigServlet
 */
@WebServlet("/Config")
public class ConfigServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     
	ServerManager serverManager = new ServerManager();
	
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	

		
		if(request.getSession().getAttribute("user_id") != null){
			int user_id = (int)request.getSession().getAttribute("user_id");
			//check if ID is admin
			if(serverManager.isAdmin(user_id)) {

				
				int ID = 0; //TODO
				int length = Integer.parseInt(request.getParameter("length"));				
				int min = Integer.parseInt(request.getParameter("min"));
				int max = Integer.parseInt(request.getParameter("max"));
				
				
				serverManager.update("UPDATE Quiz SET length = "+length+", min_participants = "+min+", max_participants = "+max+" WHERE ID = 0 ");

				request.setAttribute("msg","Wrong Username or Password");
				request.getRequestDispatcher("/success.jsp").forward(request, response);
			
			}
			else {
				request.setAttribute("msg","Your not logged in as admin!");
				request.getRequestDispatcher("/login.jsp").forward(request, response);
			
			}
			
		}else {
			request.setAttribute("msg","Your not logged in!");
			request.getRequestDispatcher("/login.jsp").forward(request, response);
		}
	}
}
