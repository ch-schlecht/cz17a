

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import application.ServerManager;

@WebServlet("/Login")
public class AdminServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		
	
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		ServerManager serverManager = new ServerManager();
		
			PrintWriter out = response.getWriter();

			String login = request.getParameter("login");
			String password = request.getParameter("password");
			
			int id = serverManager.auth(login,password);
			if(id != -1) {
			
				
				HttpSession session = request.getSession();
				session.setAttribute("user_id", id);
				//setting session to expiry in 30 mins
				session.setMaxInactiveInterval(30*60);
				Cookie userID = new Cookie("user_id", ""+id);
				userID.setMaxAge(30*60);
				response.addCookie(userID);
			
				response.sendRedirect("panel.jsp");
			}
			else {
			
				response.sendRedirect("login.jsp");
			}
			//SESSION?
			
			
		
	}

}
